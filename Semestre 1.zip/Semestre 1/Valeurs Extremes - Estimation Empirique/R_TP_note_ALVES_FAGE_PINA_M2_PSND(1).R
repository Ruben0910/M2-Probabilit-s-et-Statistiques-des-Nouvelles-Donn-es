###############################################################
###                                                         ###
###       Projet  -  Valeurs extremes                       ###
###                                                         ###
###                                                         ###
###                                                         ###
###  ALVES  Enrique -  FAGE  Annaelle  -  PINA  Ruben       ###
###                                                         ###
###############################################################

### -----------------------------
### PACKAGE ET CHARGEMENT
### -----------------------------
library(evd)

### EXERCICE 1 TP 

### -----------------------------
### QUESTION 1
### -----------------------------
data(sealevel)
plot(sealevel)


### -----------------------------
### QUESTION 2
### -----------------------------

o <- na.omit(unlist(sealevel)) 
n = length(o)

beta  <- 1
mu    <- 0
p <- (1:n)/(n+1)
qant <- mu - beta * log(-log(p))

# QQ-plot
plot(qant, sort(o),
     main = "QQ plot Gumbel")
abline(3,0.4,col="red")

### -----------------------------
### QUESTION 3
### -----------------------------


estM= fgev(o)
a_chap = estM$estimate['scale']
b_chap = estM$estimate['loc']
eta_chap = estM$estimate['shape']




# QQplot avec la loi estimé
n = length(o)
l = (1:n) /(n+1)
quanth =    b_chap + a_chap * ((-log(l))^(-eta_chap) - 1) / eta_chap
plot(quanth,sort(o),main = "QQ plot loi GEV")
abline(0,1,col ='red')

#intervalle de confiance


### -----------------------------
### QUESTION 4
### -----------------------------
prob_1 = pgev(4.2,b_chap,a_chap,eta_chap,lower.tail = FALSE)
q_995 = qgev(0.995,b_chap,a_chap,eta_chap)


### EXERCICE 2 TP 

### -----------------------------
### PACKAGE ET CHARGEMENT
### -----------------------------
library(ismev)
data(rain)

### -----------------------------
### QUESTION 1
### -----------------------------
rn <- ts(rain, start = 1914, end = 1962)
par(mfrow = c(1,2))
plot(rn, main = "Précipitations", ylab = "mm")

### -----------------------------
### QUESTION 2
### -----------------------------
rain_trie <- sort(as.numeric(rain)) # On trie les données
n <- length(rain)
k_vals <- 1:100       # On teste k de 1 à 100
xi_pickands <- numeric(100)

for(k in k_vals) {
  # statistique d'ordre
  x1 <- rain_trie[n - k]
  x2 <- rain_trie[n - 2*k]
  x4 <- rain_trie[n - 4*k]
  
  # Formule de Pickands
  xi_pickands[k] <- (1/log(2)) * log((x1 - x2) / (x2 - x4))
}

# Tracer la courbe
plot(k_vals, xi_pickands, type = "l", main = "Pickands", ylab = "Xi")
abline(h = 0, col = "red") # Ligne de référence à 0

### -----------------------------
### QUESTION 3
### -----------------------------
par(mfrow = c(1,2))
mrlplot(rain, main = "Vue globale")
mrlplot(rain, tlim = c(20,50), main = "Zoom (20-50)")

### -----------------------------
### QUESTION 4
### -----------------------------
seuils <- 20:30
xi_est <- numeric(length(seuils))
xi_se <- numeric(length(seuils))

# Boucle d'ajustement pour chaque seuil
for (i in 1:length(seuils)) {
  # Ajustement GPD (show=FALSE évite d'afficher les graphes à chaque boucle)
  fit <- gpd.fit(rain, seuils[i], show = FALSE)
  
  # Dans ismev, mle[1] = sigma, mle[2] = xi
  xi_est[i] <- fit$mle[2]
  xi_se[i]  <- fit$se[2]
}

# Graphique de stabilité avec intervalle de confiance à 95%
lower_ci <- xi_est - 1.96 * xi_se
upper_ci <- xi_est + 1.96 * xi_se

plot(seuils, xi_est, type = "b", pch = 19, ylim = range(c(lower_ci, upper_ci)),
     main = "Estimation de xi en fonction du seuil u",
     xlab = "Seuil u", ylab = expression(hat(xi)))
segments(seuils, lower_ci, seuils, upper_ci)
abline(h = mean(xi_est), col = "red", lty = 2)

### -----------------------------
### QUESTION 5
### -----------------------------
u0 = 25
fit_final <- gpd.fit(rain, u0)

# On extrait les paramètres pour les calculs
sigma <- fit_final$mle[1]
xi    <- fit_final$mle[2]
sigma_et <- fit_final$se[1]
xi_et_u0 <- fit_final$se[2]

cat("\n--- Résultats pour u0 = 25 ---\n")
cat("Sigma estimé :", round(sigma, 4), "(E-T:", round(sigma_et, 4), ")\n")
cat("Xi estimé    :", round(xi, 4), "(E-T:", round(xi_et_u0, 4), ")\n")

# b. Quantile à 99% (p = 0.99)
p <- 0.99
quantile_99 <- u0 + (sigma / xi) * ((1 - p)^(-xi) - 1)
print(quantile_99)

# c. Probabilité que Pluie > 40 sachant Pluie > 25
x_val = 40
proba <- (1 + xi * (x_val - u0) / sigma)^(-1 / xi)
print(paste("Proba > 40 sachant > 25 :", round(proba, 4)))


### -----------------------------
### QUESTION 6 : Maxima Annuels (GEV)
### -----------------------------
# a. Extraction des maxima annuels
dates <- seq(as.Date("1914-01-01"), by = "day", length.out = length(rain))
years <- format(dates, "%Y")

# Calcul du max par année
annual_max <- as.numeric(tapply(rain, years, max, na.rm = TRUE))

# 1. Calcul propre pour le modèle (Vecteur pur)
annual_max_vector <- as.numeric(tapply(rain, years, max, na.rm = TRUE))

# 2. Calcul pour le graphique (avec les noms d'années)
annual_max_plot <- tapply(rain, years, max, na.rm = TRUE)

# Visualisation
plot(as.numeric(names(annual_max_plot)), annual_max_plot, type = "h", lwd = 3,
     main = "Maxima annuels des précipitations", 
     xlab = "Année", ylab = "Max (mm)", col = "darkblue")

# 3. Ajustement GEV (sur le vecteur pur)
fit_gev <- gev.fit(annual_max_vector)

# Récupération de xi (Attention : dans gev.fit, xi est le 3ème paramètre)
xi_gev    <- fit_gev$mle[3]
xi_gev_se <- fit_gev$se[3]

ci_gpd <- c(xi - 1.96 * xi_et_u0, xi + 1.96 * xi_et_u0)
ci_gev <- c(xi_gev - 1.96 * xi_gev_se, xi_gev + 1.96 * xi_gev_se)

cat("\n--- Comparaison des estimateurs de xi ---\n")
cat("Méthode POT (GPD, u=25) : xi =", round(xi, 3), 
    " IC 95% [", round(ci_gpd[1], 3), ";", round(ci_gpd[2], 3), "]\n")
cat("Méthode Maxima (GEV)    : xi =", round(xi_gev, 3), 
    " IC 95% [", round(ci_gev[1], 3), ";", round(ci_gev[2], 3), "]\n")

# Visualisation graphique de la comparaison
par(mfrow = c(1,1))
plot(1:2, c(xi, xi_gev), xlim=c(0.5, 2.5), ylim=range(c(ci_gpd, ci_gev)),
     xaxt='n', pch=19, cex=1.5,
     main="Comparaison du paramètre de forme (xi)", 
     ylab="Valeur de xi", xlab="Méthode")

axis(1, at=1:2, labels=c("POT (GPD)", "Blocs (GEV)"))

# Ajout des intervalles de confiance
segments(1, ci_gpd[1], 1, ci_gpd[2], lwd=2, col="blue")
segments(2, ci_gev[1], 2, ci_gev[2], lwd=2, col="red")

# Barre horizontale à 0 pour voir si xi est significativement positif
abline(h = 0, lty = 2, col = "gray")
grid()
legend("topright", legend=c("GPD (Seuil)", "GEV (Blocs)"), 
       col=c("blue", "red"), lwd=2, pch=19)

