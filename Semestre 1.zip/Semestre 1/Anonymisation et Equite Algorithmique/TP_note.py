import numpy as np
import matplotlib.pyplot as plt

N = 10000

def F(X):
    return np.mean(X, axis=1)

def G(valeurs_f, n, alpha):
    scale = 1.0 / (n * alpha)
    bruit = np.random.laplace(0, scale, len(valeurs_f))
    return valeurs_f + bruit

def R(estime, theta_verite):
    return np.mean((estime - theta_verite)**2)

"""QUESTION 3.a"""

n = 500
theta = 1/2
alphas = np.linspace(0.1, 2, 50)

R_g = []
r_f = []

for a in alphas:
    X = np.random.binomial(1, theta, (N, n))
    res_F = F(X)
    res_G = G(res_F, n, a)
    R_g.append(R(res_G, theta))
    r_f.append(R(res_F, theta))

plt.plot(alphas, R_g,label = r'Risque $\tilde{R}$')
plt.plot(alphas, r_f, label = r'Risque $\tilde{r}$')
plt.xlabel('Alpha')
plt.title(r'(a) Risque en fonction de $\alpha$ ($n=500, \theta=0.5$)')
plt.legend()

"""QUESTION 3.b"""

ns = np.linspace(50, 1000, 20, dtype=int)
theta_b = 1 /2
alpha_1 = 0.5
alpha_2 = 1
alpha_3 = 1.5
R_g_n_1 = []
R_g_n_2 = []
R_g_n_3 = []
r_f_n = []

for n_val in ns:
    X = np.random.binomial(1, theta_b, (N, n_val))
    res_F = F(X)
    res_G_1 = G(res_F, n_val, alpha_1)
    res_G_2 = G(res_F, n_val, alpha_2)
    res_G_3 = G(res_F, n_val, alpha_3)
    R_g_n_1.append(R(res_G_1, theta_b))
    R_g_n_2.append(R(res_G_2, theta_b))
    R_g_n_3.append(R(res_G_3, theta_b))
    r_f_n.append(R(res_F, theta_b))

plt.plot(ns, R_g_n_1,'--', label=r'Risk confidentialisé $\tilde{R}$ $\alpha=0.5$')
plt.plot(ns, R_g_n_2,'--', label=r'Risk confidentialisé $\tilde{R}$ $\alpha=1$')
plt.plot(ns, R_g_n_3,'--', label=r'Risk confidentialisé $\tilde{R}$ $\alpha=1.5$')
plt.plot(ns, r_f_n, label=r'Risk initial $\tilde{r}$')
plt.xlabel('n')
plt.title('(b) Risque en fonction de n')
plt.legend()

"""Question 3.c"""

n_c = 500
thetas = np.linspace(0.01, 0.99, 20)

R_g_t_1 = []
R_g_t_2 = []
R_g_t_3 = []
r_f_t = []

for t in thetas:
    X = np.random.binomial(1, t, (N, n_c))
    res_F = F(X)
    res_G_1 = G(res_F, n_c, alpha_1)
    res_G_2 = G(res_F, n_c, alpha_2)
    res_G_3 = G(res_F, n_c, alpha_3)
    R_g_t_1.append(R(res_G_1, t))
    R_g_t_2.append(R(res_G_2, t))
    R_g_t_3.append(R(res_G_3, t))
    r_f_t.append(R(res_F, t))

plt.plot(thetas, R_g_t_1,'--', label=r'Risk confidentialisé $\tilde{R}$ $\alpha=0.5$')
plt.plot(thetas, R_g_t_2,'--', label=r'Risk confidentialisé $\tilde{R}$ $\alpha=1$')
plt.plot(thetas, R_g_t_3,'--', label=r'Risk confidentialisé $\tilde{R}$ $\alpha=1.5$')
plt.plot(thetas, r_f_t, label=r'Risk initial $\tilde{r}$')
plt.xlabel('Theta')
plt.title('(c) Risque en fonction Theta')
plt.legend()

"""EXERCICE 3"""

import numpy as np
import matplotlib.pyplot as plt

n = 100

alpha = 1

X = np.random.rand(n)
X.sort()
true_median = np.median(X)

candi = np.linspace(0,1, 200)

# u1(x,y)
scores_u1 = -np.sum(np.abs(X[:, None] - candi[None, :]), axis = 0)
delta_u1 = 1
logits_u1 = (alpha * scores_u1) / (2 * delta_u1)
logits_u1 -= np.max(logits_u1)
probs_u1 = np.exp(logits_u1)
probs_u1 /= np.sum(probs_u1)

#Tirage
choice_u1 = np.random.choice(candi, p=probs_u1)

# u2(x,y)
counts = np.sum(X[:, None] <= candi[None, :], axis=0)
scores_u2 = -np.abs(n/2 - counts)
delta_u2 = 1

logits_u2 = (alpha * scores_u2) / (2 * delta_u2)
logits_u2 -= np.max(logits_u2)
probs_u2 = np.exp(logits_u2)
probs_u2 /= np.sum(probs_u2)

choice_u2 = np.random.choice(candi, p=probs_u2)

plt.figure(figsize=(10, 5))
plt.plot(candi, probs_u1, label='Probs Mécanisme 1 (Distance)')
plt.plot(candi, probs_u2, label='Probs Mécanisme 2 (Rang)')
plt.axvline(true_median, color='k', linestyle='--', label='Vraie Médiane')
plt.axvline(choice_u1, color='b', linestyle=':', alpha=0.5, label='Tirage 1')
plt.axvline(choice_u2, color='orange', linestyle=':', alpha=0.5, label='Tirage 2')
plt.title('Comparaison Mécanisme Exponentiel pour la Médiane')
plt.legend()
plt.show()

print(f"Vraie médiane: {true_median:.3f}")
print(f"Est. Mécanisme 1: {choice_u1:.3f} (Erreur: {abs(choice_u1-true_median):.3f})")
print(f"Est. Mécanisme 2: {choice_u2:.3f} (Erreur: {abs(choice_u2-true_median):.3f})")

"""EXERCICE 4"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import beta, laplace
from scipy.integrate import quad

def mecanisme_histogramme_dp(data, m, alpha, support=(0, 1)):
    n = len(data)
    range_min, range_max = support
    h = (range_max - range_min) / m
    counts, bin_edges = np.histogram(data, bins=m, range=support)
    b = 2.0 / alpha
    noise = np.random.laplace(loc=0.0, scale=b, size=m)
    D_j = counts + noise
    D_j_plus = np.maximum(D_j, 0)
    total_sum = np.sum(D_j_plus)
    if total_sum > 0:
        q_hat = D_j_plus / total_sum
    else:
        q_hat = np.ones(m) / m
    density_vals = q_hat / h
    return bin_edges, density_vals

def calculer_ise(density_vals, bin_edges, true_pdf_func):
    error = 0.0
    for j in range(len(density_vals)):
        x_start = bin_edges[j]
        x_end = bin_edges[j+1]
        val_est = density_vals[j]
        integrand = lambda x: (val_est - true_pdf_func(x))**2
        res, _ = quad(integrand, x_start, x_end)
        error += res
    return error

# --- Paramètres de l'exercice ---
N_values = [1000, 10000]
Alpha_values = [0.1, 1.0, 10.0]
true_dist = beta(10, 10)

# 1. Visualisation des histogrammes confidentialisés
plt.figure(figsize=(16, 4))
plot_idx = 1
n_fixed = 5000
data = true_dist.rvs(size=n_fixed)
m_visu = 20

x_plot = np.linspace(0, 1, 200)
y_true = true_dist.pdf(x_plot)

for alpha in Alpha_values:
    edges, density = mecanisme_histogramme_dp(data, m_visu, alpha)
    plt.subplot(1, 3, plot_idx)
    plt.plot(x_plot, y_true, 'r--', label='Densité réelle Beta(10,10)', linewidth=2)
    plt.stairs(density, edges, fill=True, alpha=0.4, label=f'Alpha={alpha}')
    plt.title(f'Histogramme Confidentialisé (n={n_fixed}, m={m_visu}, $\\alpha$={alpha})')
    plt.legend()
    plot_idx += 1
plt.tight_layout()
plt.show()

# 2. Tracé de l'ISE en fonction de m
m_list = np.arange(2, 100, 5)
plt.figure(figsize=(10, 6))

n_experiment = 5000
data_exp = true_dist.rvs(size=n_experiment)

for alpha in [0.1, 10.0]:
    ise_results = []
    for m in m_list:
        monte_carlo_runs = 10
        temp_ise = 0
        for _ in range(monte_carlo_runs):
            edges, density = mecanisme_histogramme_dp(data_exp, m, alpha)
            err = calculer_ise(density, edges, true_dist.pdf)
            temp_ise += err
        ise_results.append(temp_ise / monte_carlo_runs)
    plt.plot(m_list, ise_results, 'o-', label=f'n={n_experiment}, $\\alpha$={alpha}')

plt.xlabel('Nombre de boites (m)')
plt.ylabel('ISE $\|\tilde{f} - f\|_2^2$')
plt.title('Erreur Quadratique Intégrée en fonction de m')
plt.grid(True)
plt.legend()
plt.show()